# 스니펫 설정
# {
# 	"Print to console": {
# 		"prefix": "def",
# 		"body": [
# 			"def solution($1):",
# 			"    return $2"
# 		],
# 		"description": "function 제작"
# 	}
# }
def hello(world):
    return world